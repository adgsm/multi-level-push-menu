$(document).ready(function(){
	// HTML markup implementation, overlap mode
	$( '#menu' ).multilevelpushmenu({
		direction: 'rtl',
		backItemIcon: 'fa fa-angle-left',
		groupIcon: 'fa fa-angle-right'
	});
});